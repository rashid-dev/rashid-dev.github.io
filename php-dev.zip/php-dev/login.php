<?php
include('db_connection.php');

$email = @$_POST['email'];
$password = @$_POST['password'];

if (!isset($username, $password)) {
    header('Location: index.php?login=false');
} else {

    if ($statement = $connection->prepare('SELECT name,user_id,password,role,status from tbl_users where email = ? ')) {
        $statement->bind_param('s', $email);
        $statement->execute();
        $statement->store_result();

        if ($statement->num_rows() > 0) {

            $statement->bind_result($uname, $uid, $upassword, $urole, $ustatus);
            $statement->fetch();

            if (strcmp($ustatus, 'INACTIVE') === 0) {
                
                header('Location: index.php?login=pending');

            } elseif (password_verify($password, $upassword)){

                session_regenerate_id();
                
                $_SESSION['session_logged_in'] = true;
                $_SESSION['session_user'] = $uname;
                $_SESSION['session_id'] = $uid;
                $_SESSION['session_role'] = $urole;

                header('Location: user-home.php');


            } else {

                header('Location: index.php?login=false');
            }
        } else {
            header('Location: index.php?login=false');
        }
        $statement->close();
    } else {
        echo "Query prepare failed";
    }
}


?>