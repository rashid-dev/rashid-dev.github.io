<?php
include('db_connection.php');

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirm_password = $_POST['confirm-password'];
$status = "INACTIVE";
$role = "USER";

if (!isset($name, $email, $password, $confirm_password)) {

    echo "Fill all the required feilds";
} else {

    if (strcmp($password, $confirm_password) === 0) {

        $encrypted_pass = password_hash($password, PASSWORD_BCRYPT);

        if ($statement = $connection->prepare('INSERT INTO tbl_users (name, email, password, status ,role) VALUES (?, ?, ?, ?, ?)')) {
            $statement->bind_param('sssss', $name, $email, $encrypted_pass, $status, $role);
            $statement->execute();
            $statement->close();
            header('location:index.php?registration=success');
        } else {
            header('location:index.php?registration=false');
        }
    } else {
        header('location:index.php?registration=false');
    }
}
