<?php

include('db_connection.php');


$from_time1 = date('Y-m-d H:i:s');
$to_time1 = @$_SESSION['end_time'];

$timefirst = strtotime($from_time1);
$timesecond = strtotime($to_time1);

$diffrence = $timesecond - $timefirst;



if ($diffrence < 0){
    http_response_code(400);
}
else {
    http_response_code(200);
    echo gmdate("H:i:s", $diffrence);
}

// if($diffrence === 0){
//     header('Location: https://google.com');
// }else{
//     echo gmdate("i:s", $diffrence);
// }




?>