<?php
include('db_connection.php');

unset($_SESSION['exam-id']);

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: index.php');
} else {
    if (strcmp($_SESSION['session_role'], "USER") === 0) {
    } else if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
        header('Location: Administrator/index.php');
    } else {
        header('Location: index.php');
    }
}

if ($statement = $connection->prepare('SELECT tbl_examdetails.examid from tbl_examdetails,tbl_examresult where tbl_examdetails.examid = tbl_examresult.examid and tbl_examresult.userid=?')) {
    $statement->bind_param('i',$_SESSION['session_id']);
    $statement->execute();
    $statement->store_result();
    $resultc = $statement->num_rows();
    $statement->close();
} else {
    //error connection
}



// if ($statement = $connection->prepare('SELECT * FROM tbl_examdetails')) {
if ($statement = $connection->prepare('SELECT * from tbl_examdetails where examid NOT IN (SELECT examid from tbl_examstatus WHERE userid = ?)')) {
    $statement->bind_param('i',$_SESSION['session_id']);
    $statement->execute();
    $result = $statement->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);
    $statement->close();
} else {
    //error connection
}




?>
<!doctype html>
<html>

<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Online Exam System - Dev By Masscan</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

    <div class="container-fluid">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <div class="container-fluid">
                        <span class="navbar-text">
                            <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                            <?php echo "Welcome, " . @$_SESSION['session_user']; ?>
                        </span>
                    </div>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown ">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                Settings
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu" role="menu">
                                <li class="dropdown-header">SETTINGS</li>
                                <li class=""><a href="#">Profile</a></li>
                                <li class="divider"></li>
                                <li><a href="logout.php">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container-fluid">
            <div class="col col-md-3">
                <div class="panel-group" id="accordion">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                                    Home</a>
                            </h4>
                        </div>
                        <div id="collapse1" class="panel-collapse collapse in">
                            <ul class="list-group">
                                <li class="list-group-item"><span class="badge"><?php echo $result->num_rows; ?></span> <a href="#"> Exams</a></li>

                                <li class="list-group-item"><span class="badge"><?php echo $resultc; ?></span> <a href="exam-history.php"> Exam History</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col col-md-9">
                <div class="row">
                    <table class="table table-bordered table-hover tablesorter">
                        <thead>
                            <tr>
                                <th scope="col">S.N.</th>
                                <th scope="col">Topic</th>
                                <th scope="col">Total Questions</th>
                                <th scope="col">Marks</th>
                                <th scope="col">Time Limit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($data) {
                                $i = 0;
                                foreach ($data as $row) {
                                    $i++; ?>

                                    <tr>
                                        <th scope="row"><?php echo $i; ?></th>
                                        <td><?php echo $row['examtitle']; ?></td>
                                        <td><?php echo $row['totalquestions']; ?></td>
                                        <td><?php echo $row['marksright']; ?></td>
                                        <td><?php echo $row['timelimit']; ?> (Minutes)</td>
                                        <td><button type="button" class="btn btn-info examinfo" data-id="<?php echo $row['examid']; ?>">Start</button></td>
                                    </tr>
                                <?php }
                            } else { ?>

                                <tr>
                                    <td colspan="7">No Data Found!</td>
                                </tr>

                            <?php  } ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Exam Details</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <table class='table table-bordered table-hover tablesorter'>
                            <tr>
                                <td>Exam</td>
                                <td id="exam"></td>
                            </tr>

                            <tr>
                                <td>Total Questions </td>
                                <td id="totalquestions"></td>
                            </tr>
                            <tr>
                                <td>Mark (For right answer) </td>
                                <td id="marksright"></td>
                            </tr>
                            <tr>
                                <td>Mark (For right negative answer) </td>
                                <td id="marksnegative"></td>
                            </tr>
                            <tr>
                                <td>Time Limit</td>
                                <td id="timelimit"></td>
                            </tr>
                            <tr>
                                <td>Exam Description</td>
                                <td id="examdescription"></td>
                            </tr>
                        </table>



                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <a id="startexam" href="#" class="btn btn-info start-modal"><span class="glyphicon glyphicon-new-window"></span>Start Exam</a>

                    </div>
                </div>
            </div>
        </div>


    </div>
    </div>

    <script>
        $(document).ready(function() {

            $('.examinfo').click(function() {

                var examid = $(this).data('id');

                // AJAX request
                $.ajax({
                    url: 'ajaxfile.php',
                    type: 'post',
                    data: {
                        examid: examid
                    },
                    dataType: 'json',
                    success: function(data) {
                        // Add response in Modal body
                        //$('.modal-body').html(response);

                        $('#exam').text(data['0'].examtitle);
                        $('#totalquestions').text(data['0'].totalquestions);
                        $('#marksright').text(data['0'].marksright);
                        $('#marksnegative').text(data['0'].marksnegative);
                        $('#timelimit').text(data['0'].timelimit);
                        $('#examdescription').text(data['0'].examdescription);
                        $('#startexam').attr("href", "first-time.php?examid=" + data['0'].examid);
                        // Display Modal
                        $('#myModal').modal('show');
                    }
                });
            });

        });
    </script>


</body>

</html>