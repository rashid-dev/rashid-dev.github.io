<?php

date_default_timezone_set("Asia/Calcutta");

session_start();

$servername = "localhost";

$username = "root";

$password = "";

$db = "project_exam";



// Create connection

$connection = mysqli_connect($servername, $username, $password,$db);



// Check connection

if (!$connection) {

   die("Connection failed: " . mysqli_connect_error());

}

?>