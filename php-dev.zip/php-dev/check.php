<?php
include('db_connection.php');

$userid =  $_SESSION['session_id'];
$examid =  $_SESSION['exam-id'];

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: index.php');
} else {
    if (strcmp($_SESSION['session_role'], "USER") === 0) {
    } else if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
        header('Location: Administrator/index.php');
    } else {
        header('Location: index.php');
    }
}

if(!isset($examid) || $examid==NULL){
    header('Location: user-home.php');
}

if ($statement = $connection->prepare('SELECT questionid, correctoption FROM tbl_questions where examid = ?')) {
    $statement->bind_param('i', $examid);
    $statement->execute();
    $result = $statement->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);

    if ($data) {
        foreach ($data as $raw) {
            $qid = $raw['questionid'];
            $option = @$_POST[$qid];
            if ($statement = $connection->prepare('INSERT INTO tbl_user_answers (userid, examid, questionid, user_option) VALUES (?, ?, ?, ?)')) {
                $statement->bind_param('iiis', $userid, $examid, $qid, $option);
                $statement->execute();
            } else {
                echo "Query prepare failed";
            }
        }
        $statement->close();


        if ($statement = $connection->prepare('UPDATE tbl_examstatus SET Status=1 where userid = ? and examid = ?')) {
            $statement->bind_param('ii', $userid, $examid);
            $statement->execute();
            $statement->close();

            header('Location: view-result.php');

        } else {
            echo "update status exam query failed";
        }
    } else {
        echo "No Questions found";
    }
} else {
    echo "query error";
}

?>


