<?php
include('db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: index.php');
}


$examid = @$_GET['examid'];
$userid = @$_SESSION['session_id'];

if ($statement = $connection->prepare('SELECT statusid from tbl_examstatus where examid = ? and userid = ?')) {
    $statement->bind_param('ii', $examid, $_SESSION['session_id']);
    $statement->execute();
    $statement->store_result();
    if ($statement->num_rows() > 0) {
        header('Location: user-home.php?m=1');
    } elseif ($statement = $connection->prepare('SELECT questionid FROM tbl_questions WHERE examid = ?')) {
        $statement->bind_param('i', $examid);
        $statement->execute();
        $statement->store_result();

        if ($statement->num_rows() > 0) {
            if ($statement = $connection->prepare('SELECT timelimit FROM tbl_examdetails WHERE examid = ?')) {
                $statement->bind_param('i', $examid);
                $statement->execute();
                $statement->store_result();

                if ($statement->num_rows() >  0) {
                    $statement->bind_result($timelimit);
                    $statement->fetch();

                    $statement->close();

                    $status = 0; //attempted

                    if ($statement = $connection->prepare('INSERT INTO tbl_examstatus (userid, examid, status) VALUES (?, ?, ?)')) {
                        $statement->bind_param('iii', $userid, $examid, $status);
                        $statement->execute();
                        $statement->close();

                        $_SESSION['duration'] = $timelimit;
                        $_SESSION['start_time'] = date("Y-m-d H:i:s");
                        $endtime = date('Y-m-d H:i:s', strtotime('+' . $_SESSION['duration'] . 'minutes', strtotime($_SESSION["start_time"])));
                        $_SESSION['end_time'] = $endtime;
                        $_SESSION['exam-id'] = $examid;


                        header('Location: startexam.php');
                    } else {
                        echo "update status exam query failed";
                    }
                } else {
                    echo "No such exam";
                }
            } else {
                echo "Query prepare error";
            }
        } else {
            echo "No Questions Found. Sorry!";
        }
    } else {
        echo  "Query prepare error";
    }
}
