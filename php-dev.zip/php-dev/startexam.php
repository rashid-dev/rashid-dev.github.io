<?php

include('db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: index.php');
} else {
    if (strcmp($_SESSION['session_role'], "USER") === 0) {
    } else if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
        header('Location: Administrator/index.php');
    } else {
        header('Location: index.php');
    }
}

$examid = @$_SESSION['exam-id'];

if(!isset($examid) || $examid==NULL){
    header('Location: user-home.php');
}

if ($statement = $connection->prepare('SELECT examtitle FROM tbl_examdetails where examid = ?')) {
    $statement->bind_param('i', $examid);
    $statement->execute();
    $statement->store_result();
    if ($statement->num_rows() > 0) {
        $statement->bind_result($exam_title);
        $statement->fetch();
        $statement->close();
    } else {
        echo "No result";
    }
} else {
    echo "connectione error";
}

if ($statement = $connection->prepare('SELECT * FROM tbl_questions WHERE examid = ?')) {

    $statement->bind_param('i', $examid);

    $statement->execute();

    $result = $statement->get_result();

    $data = $result->fetch_all(MYSQLI_ASSOC);
} else {
    //connection error;
}


?>



<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Exam</title>
</head>

<body>


    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 mx-auto col-12">
                <div class="table-wrapper shadow-sm p-3 p-md-5  mb-1 bg-white rounded ">
                    <h1 class="text-center"> <?php echo @$exam_title; ?></h1>
                    <h3 class="text-center mb-5">Time Left: <span id="timer">Loading...</span></h3>
                    <div class="form-wrapper">

                        <form role="form" action="check.php" method="POST">

                            <?php if ($data) {
                                $i = 1;
                                foreach ($data as $row) {
                            ?>

                                    <!-- Question 1 -->
                                    <div class="question-wrapper shadow-none p-5 mb-5 bg-light rounded">
                                        <div class="form-group">
                                            <label>Question <?php echo $i; ?></label>
                                            <p class="font-weight-bold"><?php echo $row['question'] ?></p>
                                        </div>
                                        <div class="form-group">
                                            <input class="form-check-input" type="radio" name="<?php echo $row['questionid'];  ?>" value="Option A">
                                            <label class="form-check-label" for="q1-option1">
                                                <?php echo $row['optiona']; ?>
                                            </label>
                                        </div>
                                        <div class="form-group">
                                            <input class="form-check-input" type="radio" name="<?php echo $row['questionid'];  ?>" value="Option B">
                                            <label class="form-check-label" for="q1-option2">
                                                <?php echo $row['optionb']; ?>
                                            </label>
                                        </div>
                                        <div class="form-group">
                                            <input class="form-check-input" type="radio" name="<?php echo $row['questionid'];  ?>" value="Option C">
                                            <label class="form-check-label" for="q1-option3">
                                                <?php echo $row['optionc']; ?>
                                            </label>
                                        </div>
                                        <div class="form-group">
                                            <input class="form-check-input" type="radio" name="<?php echo $row['questionid'];  ?>" value="Option D">
                                            <label class="form-check-label" for="q1-option4">
                                                <?php echo $row['optiond']; ?>
                                            </label>
                                        </div>
                                    </div>

                            <?php $i++;
                                }
                            } ?>


                            <button type="submit" class="btn btn-primary">Submit</button>
                            <button type="submit" class="btn btn-secondary">Clear</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        setInterval(function() {

            var xmlhttp = new XMLHttpRequest();
            xmlhttp.open("GET", "response.php", false);
            xmlhttp.send(null);

            if (xmlhttp.status === 200) {
                document.getElementById("timer").innerHTML = xmlhttp.responseText;
            } else if (xmlhttp.status === 400) {

                location.href = "logout.php";
            }


        }, 1000);

        history.pushState(null, document.title, location.href);
        window.addEventListener('popstate', function(event) {
            history.pushState(null, document.title, location.href);
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- <script type="text/javascript">
        $('.form-check-input').on('change',function(){
            $('.form-check-input').not(this).prop('checked', false);
        });
    </script> -->


</body>

</html>