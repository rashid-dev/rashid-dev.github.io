<?php
include("db_connection.php");

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: index.php');
} else {
    if (strcmp($_SESSION['session_role'], "USER") === 0) {
    } else if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
        header('Location: Administrator/index.php');
    } else {
        header('Location: index.php');
    }
}

if (isset($_POST['examid'])) {

    $examid = @$_POST['examid'];

    if ($statement = $connection->prepare('SELECT * FROM tbl_examdetails WHERE examid = ?')) {
        $statement->bind_param('i', $examid);
        $statement->execute();
        $result = $statement->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);

        echo json_encode($data);
    } else {
        //error connection
    }
}


?>

