<?php
include('../db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: ../index.php');
} else {
    if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
    } else if (strcmp($_SESSION['session_role'], "USER") === 0) {
        header('Location: ../index.php');
    } else {
        header('Location: ../index.php');
    }
}

$examid = @$_GET['exam_id'];

if (!isset($examid) || $examid == NULL) {
    header('Location: list-exam.php');
}


if ($statement = $connection->prepare('SELECT * FROM tbl_examdetails WHERE examid = ?')) {
    $statement->bind_param('i', $examid);
    $statement->execute();
    $result = $statement->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);
} else {
    echo "Query prepare failed";
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard - Exam Admin</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="http://cdn.oesmith.co.uk/morris-0.4.3.min.css">
</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Exam Admin</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav side-nav">
                    <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                                class="fa fa-caret-square-o-down"></i> Students <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="student-all.php">List Students</a></li>
                            <li><a href="student-new.php">New Students</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                                class="fa fa-caret-square-o-down"></i> Exams <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="list-exam.php">List Exams</a></li>
                            <li><a href="add-exam.php">Add Exam</a></li>
                            <li><a href="exam-result.php">Result</a></li>
                        </ul>
                    </li>
                </ul>

                <ul class="nav navbar-nav navbar-right navbar-user">
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo @$_SESSION['session_user']; ?> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
                            <li class="divider"></li>
                            <li><a href="../logout.php"><i class="fa fa-power-off"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <ol class="breadcrumb">
                        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                        <li class="active"><i class="fa fa-edit"></i> Edit Exam</li>
                    </ol>
                </div>
            </div><!-- /.row -->

            <div class="row">
                <div class="col-lg-6 col-lg-offset-1">

                    <?php if (strcmp(@$_GET['action'], 'error') === 0) { ?>

                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error!</strong> Some error occured. Please try again .
                        </div>

                    <?php } ?>


                    <h1>Edit Exam Details</h1>

                    <?php
                    if ($data) {
                        foreach ($data as $row) {

                    ?>

                            <form role="form" action="edit-exam-details.php" method="POST">

                                <div class="form-group">
                                    <label>Enter Exam Title</label>
                                    <input class="form-control" type="hidden" name="exam_id" value="<?php echo $row['examid'];  ?>" required>
                                    <input class="form-control" type="text" name="exam_title" value="<?php echo $row['examtitle'];  ?>" required>
                                </div>

                                <div class="form-group">
                                    <label>Enter Total Number of Questions</label>
                                    <input class="form-control" type="text" name="total_questions" value="<?php echo $row['totalquestions'] ?>" required>
                                </div>

                                <div class="form-group">
                                    <label>Enter Marks for Right Answer</label>
                                    <input class="form-control" type="text" name="marks_right" value="<?php echo $row['marksright'] ?>" required>
                                </div>

                                <div class="form-group">
                                    <label>Enter Minus Marks for Negative Answer</label>
                                    <input class="form-control" type="text" name="marks_negative" value="<?php echo $row['marksnegative'] ?>" required>
                                </div>

                                <div class="form-group">
                                    <label>Enter Time Limit (Minutes)</label>
                                    <input class="form-control" placeholder="Enter Time Limit in Minutes" value="<?php echo $row['timelimit'] ?>" type="text" name="time_limit" required>
                                </div>

                                <div class="form-group">
                                    <label>Exam Description</label>
                                    <textarea class="form-control" rows="3" type="text" name="exam_desc" required><?php echo $row['examdescription']  ?></textarea>
                                </div>



                                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                                <button type="reset" class="btn btn-default">Reset</button>

                            </form>
                        <?php  }
                    } else { ?>

                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error!</strong> Invalid exam.
                        </div>

                    <?php   } ?>
                </div>

            </div><!-- /.row -->

        </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

</body>

</html>