<?php
include('../db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: ../index.php');
} else {
    if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
    } else if (strcmp($_SESSION['session_role'], "USER") === 0) {
        header('Location: ../index.php');
    } else {
        header('Location: ../index.php');
    }
}


$examid = @$_POST['exam_id'];
$examTitle = @$_POST['exam_title'];
$totalQuestions = @$_POST['total_questions'];
$marksRight = @$_POST['marks_right'];
$marksNegative = @$_POST['marks_negative'];
$timeLimit = @$_POST['time_limit'];
$examDesc = @$_POST['exam_desc'];


if (!isset($examid, $examTitle, $totalQuestions, $marksRight, $marksNegative, $timeLimit, $examDesc)) {
    header('Location: edit-exam.php');
} else {

    if ($statement = $connection->prepare('UPDATE tbl_examdetails SET examtitle=?, totalquestions=?, marksright=?, marksnegative=?, timelimit=?, examdescription=? where examid = ?')) {

        $statement->bind_param('siiiisi', $examTitle, $totalQuestions, $marksRight, $marksNegative, $timeLimit, $examDesc, $examid);
        if ($statement->execute()){
            header('location:list-exam.php');
        }else{
            header('location:edit-exam.php?action=error');
        }
        $statement->close();

    } else {
        echo "Query prepare failed";
    }
}

?>