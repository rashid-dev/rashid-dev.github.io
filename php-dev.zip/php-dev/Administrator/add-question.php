<?php

include('../db_connection.php');

$exam_id = @$_GET['exam_id'];
$success = NULL;
$error = NULL;
$warning = NULL;
$question_no = NULL;


if ($statement = $connection->prepare('SELECT totalquestions FROM tbl_examdetails where examid = ?')) {
    $statement->bind_param('i', $exam_id);
    $statement->execute();
    $statement->store_result();

    if ($statement->num_rows > 0) {
        $statement->bind_result($totalq);
        $statement->fetch();
        $statement->close();
    } else {
        header('Location: list-exam.php');
    }
} else {
    echo "query failed";
}


function numberQuestion($connection, $exam_id)
{

    global $question_no, $error;

    if ($statement = $connection->prepare('SELECT questionid FROM tbl_questions WHERE examid = ?')) {
        $statement->bind_param('i', $exam_id);
        $statement->execute();
        $statement->store_result();

        if ($statement->num_rows() > 0) {
            $question_no = $statement->num_rows() + 1;
            $statement->close();
        } else {
            $question_no = 1;
        }
    } else {
        $error = 1;
    }
}

$qustion = $option_a = $option_b = $option_c = $option_d = $correct_option = NULL;

if (!isset($exam_id)) {
    header('Location: list-exam.php');
} else {
    numberQuestion($connection, $exam_id);
}

if (isset($_POST['submit'])) {

    $qustion = @$_POST['question'];
    $option_a = @$_POST['optiona'];
    $option_b = @$_POST['optionb'];
    $option_c = @$_POST['optionc'];
    $option_d = @$_POST['optiond'];
    $correct_option = @$_POST['correctoption'];


    if (isset($qustion, $option_a, $option_b, $option_c, $option_d, $correct_option, $exam_id)) {

        if ($question_no <= $totalq) {

            //echo $qustion, $option_a, $option_b, $option_c, $option_d, $correct_option, $exam_id;

            if ($statement = $connection->prepare('INSERT INTO tbl_questions (examid, question, optiona, optionb, optionc, optiond, correctoption) VALUES (?, ?, ?, ?, ?, ?, ?)')) {
                $statement->bind_param('issssss', $exam_id, $qustion, $option_a, $option_b, $option_c, $option_d, $correct_option);

                if ($statement->execute()) {
                    $success = 1;
                } else {
                    $error = 1;
                }
                $statement->close();
            } else {
                $error = 1;
            }
        } else {
            $error = 1;
        }
    } else {
        $warning = 1;
    }
    numberQuestion($connection, $exam_id);
}





?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard - Exam Admin</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="http://cdn.oesmith.co.uk/morris-0.4.3.min.css">
</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Exam Admin</a>
            </div>

            <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav side-nav">
                    <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                                class="fa fa-caret-square-o-down"></i> Students <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="student-all.php">List Students</a></li>
                            <li><a href="student-new.php">New Students</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                                class="fa fa-caret-square-o-down"></i> Exams <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="list-exam.php">List Exams</a></li>
                            <li><a href="add-exam.php">Add Exam</a></li>
                            <li><a href="exam-result.php">Result</a></li>
                        </ul>
                    </li>
                </ul>

                <ul class="nav navbar-nav navbar-right navbar-user">
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo @$_SESSION['session_user']; ?> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
                            <li class="divider"></li>
                            <li><a href="../logout.php"><i class="fa fa-power-off"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <h1>Exam <small>Enter Questions</small></h1>
                    <ol class="breadcrumb">
                        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                        <li class="active"><i class="fa fa-edit"></i> Exams</li>
                    </ol>

                </div>
            </div><!-- /.row -->

            <div class="row">
                <div class="col-lg-8">

                    <?php if (isset($success)) { ?>

                        <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success!</strong> Exam added successfully.
                        </div>

                    <?php } ?>

                    <?php if (isset($error)) { ?>

                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error!</strong> Problem while adding question.
                        </div>

                    <?php } ?>

                    <?php if (isset($error)) { ?>

                        <div class="alert alert-warning alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Warning!</strong> Fill all required fields.
                        </div>

                    <?php } ?>

                    <?php

                    if ($question_no <= @$totalq) {

                    ?>

                        <form role="form" action="" method="POST">

                            <div class="form-group">
                                <label>Question <?php echo $question_no; ?> </label>
                                <textarea class="form-control" rows="3" placeholder="Write Qustion 1 here..." name="question" required></textarea>
                            </div>

                            <div class="form-group">
                                <label>Option A</label>
                                <input class="form-control" placeholder="Enter option A" name="optiona" required>
                            </div>

                            <div class="form-group">
                                <label>Option B</label>
                                <input class="form-control" placeholder="Enter option B" name="optionb" required>
                            </div>

                            <div class="form-group">
                                <label>Option C</label>
                                <input class="form-control" placeholder="Enter option C" name="optionc" required>
                            </div>

                            <div class="form-group">
                                <label>Option D</label>
                                <input class="form-control" placeholder="Enter option D" name="optiond" required>
                            </div>


                            <div class="form-group">
                                <label>Select correct answer</label>
                                <select class="form-control" required name="correctoption">
                                    <option value="">select</option>
                                    <option value="Option A">Option A</option>
                                    <option value="Option B">Option B</option>
                                    <option value="Option C">Option C</option>
                                    <option value="Option D">Option D</option>
                                </select>
                            </div>



                            <button type="submit" name="submit" class="btn btn-primary">Add Another</button>
                            <button type="reset" class="btn btn-default">Reset</button>

                        </form>
                    <?php } else { ?>
                        <div class="alert alert-warning alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Warning!</strong> All Questions Added Successfuly.
                        </div>
                    <?php } ?>


                </div>
            </div><!-- /.row -->

        </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

</body>

</html>