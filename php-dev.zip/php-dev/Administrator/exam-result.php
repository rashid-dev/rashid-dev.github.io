<?php

include('../db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: ../index.php');
} else {
    if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
    } else if (strcmp($_SESSION['session_role'], "USER") === 0) {
        header('Location: ../index.php');
    } else {
        header('Location: ../index.php');
    }
}

if ($statement = $connection->prepare('SELECT examid, examtitle FROM tbl_examdetails')) {
    $statement->execute();
    $result = $statement->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);
} else {
    //error connection
}




?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard - Exam Admin</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="http://cdn.oesmith.co.uk/morris-0.4.3.min.css">
</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Exam Admin</a>
            </div>

            <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav side-nav">
                    <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                                class="fa fa-caret-square-o-down"></i> Students <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="student-all.php">List Students</a></li>
                            <li><a href="student-new.php">New Students</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                                class="fa fa-caret-square-o-down"></i> Exams <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="list-exam.php">List Exams</a></li>
                            <li><a href="add-exam.php">Add Exam</a></li>
                            <li><a href="exam-result.php">Result</a></li>
                        </ul>
                    </li>
                </ul>

                <ul class="nav navbar-nav navbar-right navbar-user">
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo @$_SESSION['session_user']; ?> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
                            <li class="divider"></li>
                            <li><a href="../logout.php"><i class="fa fa-power-off"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <ol class="breadcrumb">
                        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                        <li class="active"><i class="fa fa-edit"></i> Result</li>
                    </ol>
                </div>
            </div><!-- /.row -->

            <div class="row">
                <div class="col-lg-6 col-lg-offset-1">

                    <?php if (strcmp(@$_GET['action'], 'success') === 0) { ?>

                        <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success!</strong> Exam added successfully.
                        </div>

                    <?php } ?>

                    <?php if (strcmp(@$_GET['action'], 'error') === 0) { ?>

                        <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Error!</strong> Some error occured. Please try again .
                        </div>

                    <?php } ?>



                    <div class="form-group">
                        <label>Select Exam</label>
                        <select class="form-control" id="exam" required>
                            <option value="-1">select</option>
                            <?php if (@$data) {
                                foreach ($data as $row) { ?>
                                    <option value="<?php echo $row['examid']; ?>"><?php echo $row['examtitle']; ?></option>
                            <?php }
                            } ?>
                        </select>
                    </div>

                    <h2>Result</h2>
                    <div class="table-responsive">
                        <input type="text" class="form-control" id="myInput" onkeyup="myFunction()" placeholder="Search for students..">
                        <br />
                        <table class="table table-bordered table-hover table-striped tablesorter" id="resulttable">
                            <thead>
                                <tr>
                                    <th>S.N</th>
                                    <th>Student Name</th>
                                    <th>Right Answers</th>
                                    <th>Wrong Answers</th>
                                    <th>Unattended Questions</th>
                                    <th>Score</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>

                </div>

            </div><!-- /.row -->

        </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>
    <script>
        $(document).ready(function() {
            $("#exam").change(function() {
                var exam_id = $(this).val();
                if (exam_id != "") {
                    $.ajax({
                        url: "get-result.php",
                        data: {
                            exam_id: exam_id
                        },
                        type: 'POST',
                        dataType: 'json',
                        success: function(response) {
                            var len = response.length;
                            if (len > 0) {
                                $("#resulttable tbody tr").remove();
                                for (var i = 0; i < len; i++) {
                                    var username = response[i].name;
                                    var right = response[i].rightquestions;
                                    var wrong = response[i].wrongquestions;
                                    var unattended = response[i].unattended;
                                    var score = response[i].score;

                                    var tr_str = "<tr>" +
                                        "<td>" + (i + 1) + "</td>" +
                                        "<td>" + username + "</td>" +
                                        "<td>" + right + "</td>" +
                                        "<td>" + wrong + "</td>" +
                                        "<td>" + unattended + "</td>" +
                                        "<td>" + score + "</td>" +
                                        "</tr>";

                                    $("#resulttable tbody").append(tr_str);
                                }
                            } else {
                                $("#resulttable tbody tr").remove();
                                var tr_str = "<tr>" +
                                    "<td colspan='6'>" + "No Result Found!" + "</td>" +
                                    "</tr>";

                                $("#resulttable tbody").append(tr_str);
                            }

                        }
                    });
                }
            });
        });
    </script>

    <script>
        function myFunction() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("resulttable");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>
</body>

</html>