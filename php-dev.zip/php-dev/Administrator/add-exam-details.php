<?php
include('../db_connection.php');

$examTitle = @$_POST['exam_title'];
$totalQuestions = @$_POST['total_questions'];
$marksRight = @$_POST['marks_right'];
$marksNegative = @$_POST['marks_negative'];
$timeLimit = @$_POST['time_limit'];
$examDesc = @$_POST['exam_desc'];


if (!isset($examTitle, $totalQuestions, $marksRight, $marksNegative, $timeLimit, $examDesc)) {
    header('Location: add-exam.php');
} else {

    if ($statement = $connection->prepare('INSERT INTO tbl_examdetails (examtitle, totalquestions, marksright, marksnegative, timelimit, examdescription) VALUES (?, ?, ?, ?, ?, ?)')) {

        $statement->bind_param('siiiis', $examTitle, $totalQuestions, $marksRight, $marksNegative, $timeLimit, $examDesc);
        $statement->execute();
        $statement->close();

        header('location:add-exam.php?action=success');
    } else {
        header('location:add-exam.php?action=error');
    }
}

?>