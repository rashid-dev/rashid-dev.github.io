<?php

include('../db_connection.php');


$examid = @$_GET['exam_id'];

if (!isset($examid) || $examid == NULL) {
    header('Location: list-exam.php');
} else {
    if ($statement = $connection->prepare('SELECT * FROM tbl_questions where examid = ?')) {
        $statement->bind_param('i', $examid);
        $statement->execute();
        $result = $statement->get_result();
        $statement->close();
        if ($result->num_rows > 0) {
            $data = $result->fetch_all(MYSQLI_ASSOC);
        }
    } else {
        echo "Query prepare failed";
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Dashboard - Exam Admin</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="http://cdn.oesmith.co.uk/morris-0.4.3.min.css">
</head>

<body>

    <div id="wrapper">

        <!-- Sidebar -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Exam Admin</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav side-nav">
                    <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                                class="fa fa-caret-square-o-down"></i> Students <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="student-all.php">List Students</a></li>
                            <li><a href="student-new.php">New Students</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                                class="fa fa-caret-square-o-down"></i> Exams <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="list-exam.php">List Exams</a></li>
                            <li><a href="add-exam.php">Add Exam</a></li>
                            <li><a href="exam-result.php">Result</a></li>
                        </ul>
                    </li>
                </ul>

                <ul class="nav navbar-nav navbar-right navbar-user">
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo @$_SESSION['session_user']; ?> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#"><i class="fa fa-user"></i> Profile</a></li>
                            <li class="divider"></li>
                            <li><a href="../logout.php"><i class="fa fa-power-off"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="row">
                <div class="col-lg-12">
                    <h1>Questions <small>Manage Questions</small></h1>
                    <ol class="breadcrumb">
                        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                        <li class="active"><i class="fa fa-table"></i> Exams</li>
                    </ol>
                </div>
            </div><!-- /.row -->

            <div class="row">
                <div class="col-lg-10">
                    <h2>Question List</h2>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover tablesorter">
                            <thead>
                                <tr>
                                    <th>S.N. <i class="fa fa-sort"></i></th>
                                    <th>Question <i class="fa fa-sort"></i></th>
                                    <th>Option A <i class="fa fa-sort"></i></th>
                                    <th>Option B <i class="fa fa-sort"></i></th>
                                    <th>Option C <i class="fa fa-sort"></i></th>
                                    <th>Option D <i class="fa fa-sort"></i></th>
                                    <th>Correct Option <i class="fa fa-sort"></i></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (@$data) {
                                    $i = 0;
                                    foreach ($data as $row) {
                                        $i++; ?>
                                        <tr>
                                            <td><?php echo $i ?></td>
                                            <td><?php echo $row['question'] ?></td>
                                            <td><?php echo $row['optiona'] ?></td>
                                            <td><?php echo $row['optionb'] ?></td>
                                            <td><?php echo $row['optionc'] ?></td>
                                            <td><?php echo $row['optiond'] ?></td>
                                            <td><?php echo $row['correctoption'] ?></td>
                                            <td><a href="edit-question.php?question_id=<?php echo $row['questionid']; ?>&exam_id=<?php echo $examid; ?>" class="btn btn-primary"><span class="fa fa-table"></span> Edit</a></td>
                                            <td><a onclick="javascript: return confirm('Please confirm deletion')" href="delete-question.php?question_id=<?php echo $row['questionid'];  ?>&exam_id=<?php echo $examid; ?>" class="btn btn-danger"><span class="fa fa-table"></span> Delete</a></td>

                                        </tr>
                                    <?php }
                                } else { ?>
                                    <tr>
                                        <td colspan="7">No Questions added yet!</td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div><!-- /.row -->

        </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

</body>

</html>