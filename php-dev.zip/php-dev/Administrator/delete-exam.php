<?php
include('../db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: ../index.php');
} else {
    if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
    } else if (strcmp($_SESSION['session_role'], "USER") === 0) {
        header('Location: ../index.php');
    } else {
        header('Location: ../index.php');
    }
}


$examid = @$_GET['exam_id'];

if (!isset($examid) || empty($examid)) {
    header('Location: list-exam.php');
} else {
    $statement = $connection->prepare('DELETE tbl_examdetails,tbl_questions, tbl_examresult, tbl_examstatus, tbl_user_answers FROM tbl_examdetails 
    LEFT JOIN tbl_questions 
    ON tbl_questions.examid = tbl_examdetails.examid 
    LEFT JOIN tbl_examresult
    ON tbl_examresult.examid = tbl_examdetails.examid
    LEFT JOIN tbl_examstatus
    ON tbl_examstatus.examid = tbl_examdetails.examid
    LEFT JOIN tbl_user_answers
    ON tbl_user_answers.examid = tbl_user_answers.examid
    WHERE tbl_examdetails.examid = ? ');
    $statement->bind_param('i', $examid);
    
    if ($statement->execute()) {
        $affected = $statement->affected_rows;
        if ($affected > 0) {
            header('Location: list-exam.php?delete=success');
        } else {
            header('Location: list-exam.php?delete=false');
        }
    } else {
        header('Location: list-exam.php?delete=error');
    }
}
