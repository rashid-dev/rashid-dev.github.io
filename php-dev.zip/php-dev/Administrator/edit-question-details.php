<?php
include('../db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: ../index.php');
} else {
    if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
    } else if (strcmp($_SESSION['session_role'], "USER") === 0) {
        header('Location: ../index.php');
    } else {
        header('Location: ../index.php');
    }
}
$eid  = @$_POST['exam_id'];
$qid = @$_POST['question_id'];
$question = @$_POST['question'];
$optiona = @$_POST['optiona'];
$optionb = @$_POST['optionb'];
$optionc = @$_POST['optionc'];
$optiond = @$_POST['optiond'];
$correctoption = @$_POST['correctoption'];

if (!isset($eid, $qid, $question, $optiona, $optionb, $optionc, $optiond, $correctoption)) {
    header('Location: edit-question.php');
} else {

    //echo $qid."---".$question."---".$optiona."---".$optionb."---".$optionc."---".$optiond."---".$correctoption;
    if ($statement = $connection->prepare('UPDATE tbl_questions SET question=?, optiona=?, optionb=?, optionc=?, optiond=?, correctoption=? where questionid = ?')) {

        $statement->bind_param('ssssssi', $question, $optiona, $optionb, $optionc, $optiond, $correctoption, $qid);
        if ($statement->execute()){
            header('location:view-question.php?exam_id='.$eid.'&qupdate=success');
        }else{
            header('location:view-question.php?exam_id='.$eid.'&qupdate=false');
        }
        $statement->close();

    } else {
        echo "Query prepare failed";
    }
}

?>