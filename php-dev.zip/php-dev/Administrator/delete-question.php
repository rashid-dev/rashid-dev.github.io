<?php
include('../db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: ../index.php');
} else {
    if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
    } else if (strcmp($_SESSION['session_role'], "USER") === 0) {
        header('Location: ../index.php');
    } else {
        header('Location: ../index.php');
    }
}


$qid = @$_GET['question_id'];
$eid = @$_GET['exam_id'];

if (!isset($qid,$eid) || empty($qid) || empty($eid)) {
    header('Location: list-exam.php');
} else {
    $statement = $connection->prepare('DELETE FROM tbl_questions where questionid = ?');
    $statement->bind_param('i', $qid);
    
    if ($statement->execute()) {
        $affected = $statement->affected_rows;
        if ($affected > 0) {
            header('location:view-question.php?exam_id='.$eid.'&qdelete=success');
        } else {
            header('location:view-question.php?exam_id='.$eid.'&qdelete=false');
        }
    } else {
        header('location:view-question.php?exam_id='.$eid.'&qdelete=false');
    }
}
