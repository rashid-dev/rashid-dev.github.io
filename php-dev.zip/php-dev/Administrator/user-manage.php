<?php
include('../db_connection.php');

$userid = @$_GET['user_id'];
$action = @$_GET['action'];

if (!isset($userid, $action) || $userid == NULL || $action == NULL) {
    header('Location: student-list.php');
} else {

    if(strcmp($action, 'delete') === 0){
        if ($statement = $connection->prepare('DELETE FROM tbl_users where user_id = ? and status = "ACTIVE" and role = "USER"')) {
            $statement->bind_param('i', $userid);
            $statement->execute();
            $affected = $statement->affected_rows;
            $statement->close();
            if($affected > 0){
                header('Location: student-all.php?delete=success');
            }else{
                header('Location: student-all.php?delete=error');
            }
        } else {
            echo "Query prepare error";
        }

    }elseif (strcmp($action, 'approve') === 0) {
        if ($statement = $connection->prepare('UPDATE tbl_users SET status = "ACTIVE" where user_id = ?')) {
            $statement->bind_param('i', $userid);
            $statement->execute();
            $affected = $statement->affected_rows;
            $statement->close();
            if($affected > 0){
                header('Location: student-new.php?update=success');
            }else{
                header('Location: student-new.php?update=error');
            }


        } else {
            echo "Query prepare error";
        }
    } elseif (strcmp($action, 'reject') === 0) {
        if ($statement = $connection->prepare('DELETE FROM tbl_users where user_id = ? and status = "INACTIVE" and role = "USER"')) {
            $statement->bind_param('i', $userid);
            $statement->execute();
            $affected = $statement->affected_rows;
            $statement->close();
            if($affected > 0){
                header('Location: student-new.php?delete=success');
            }else{
                header('Location: student-new.php?delete=error');
            }
        } else {
            echo "Query prepare error";
        }
    }else{
        header('Location: student-list.php');
    }

}
