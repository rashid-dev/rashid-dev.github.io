<?php

include('../db_connection.php');

if (isset($_POST['exam_id'])) {

    $examid = @$_POST['exam_id'];

    if ($statement = $connection->prepare('SELECT tbl_examdetails.examtitle,tbl_examresult.*,tbl_users.name from tbl_examdetails,tbl_examresult,tbl_users where tbl_examdetails.examid = tbl_examresult.examid and tbl_users.user_id=tbl_examresult.userid and tbl_examresult.examid=?')) {
        $statement->bind_param('i',$examid);
        $statement->execute();
        $result = $statement->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        $statement->close();
        echo json_encode($data);
    
    } else {
        //error connection
    }
    
}


?>