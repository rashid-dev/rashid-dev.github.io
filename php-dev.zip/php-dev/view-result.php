<?php

include('db_connection.php');

if (!isset($_SESSION['session_logged_in'], $_SESSION['session_user'], $_SESSION['session_id'], $_SESSION['session_role'])) {

    header('Location: index.php');
} else {
    if (strcmp($_SESSION['session_role'], "USER") === 0) {
    } else if (strcmp($_SESSION['session_role'], "ADMIN") === 0) {
        header('Location: Administrator/index.php');
    } else {
        header('Location: index.php');
    }
}


$userid =  @$_SESSION['session_id'];
$examid =  @$_SESSION['exam-id'];
$examidpost = @$_POST['exam-id'];;

if (isset($examidpost)) {
    $examid = $examidpost;
} elseif (!isset($userid, $examid)) {
    header('Location: user-home.php');
}


$correct = 0;
$wrong = 0;
$score = 0;
$unattended = 0;
$overall = 0;


if ($statement = $connection->prepare('SELECT questionid, correctoption FROM tbl_questions where examid = ?')) {
    $statement->bind_param('i', $examid);
    $statement->execute();
    $result = $statement->get_result();
    $data = $result->fetch_all(MYSQLI_ASSOC);
    $statement->close();

    if ($data) {
        foreach ($data as $raw) {

            if ($statement = $connection->prepare('SELECT user_option FROM tbl_user_answers where examid = ? AND userid = ? AND questionid = ?')) {
                $statement->bind_param('iii', $examid, $userid, $raw['questionid']);
                $statement->execute();
                $examresult = $statement->get_result();
                $examdata = $examresult->fetch_all(MYSQLI_ASSOC);
                $statement->close();

                if ($examdata) {
                    foreach ($examdata as $raw_Second) {
                        if ($raw['correctoption'] === $raw_Second['user_option']) {
                            $correct += 1;
                        } elseif ($raw_Second['user_option'] === NULL) {
                            $unattended += 1;
                        } else {
                            $wrong += 1;
                        }
                    }
                } else {
                    header('Location: user-home.php');
                }
            } else {
                echo "query prepare error";
            }
        }
    } else {
        header('Location: user-home.php');
    }
} else {
    echo "Connection query prepare error";
}


if ($statement = $connection->prepare('SELECT marksright, marksnegative FROM tbl_examdetails where examid = ?')) {
    $statement->bind_param('i', $examid);
    $statement->execute();
    $statement->store_result();

    if ($statement->num_rows()) {
        $statement->bind_result($positive, $negative);
        $statement->fetch();

        $overall = ($correct * $positive) - ($wrong * $negative);
    } else {
        echo "No Exam Data Found";
    }
} else {
    echo "Query prepare failed";
}

if ($statement = $connection->prepare('INSERT INTO tbl_examresult (userid, examid, rightquestions, wrongquestions, unattended, score) VALUES (?, ?, ?, ?, ?, ?)')){
    $statement->bind_param('iiiiii', $userid, $examid, $correct, $wrong, $unattended, $overall);
    $statement->execute();
}else{
    echo "Query prepare failed";
}


unset($_SESSION['exam-id']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Exam- Result</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Exam Result</h2>
  <p>Your exam result is shown below:</p>            
  <table class="table table-hover">
    <tbody>
    <tr>
            <td>Total Questions : </td>
            <td><?php echo $result->num_rows;  ?></td>
        </tr>
        <tr>
            <td>Right Answers : </td>
            <td><?php echo $correct; ?></td>
        </tr>
        <tr>
            <td>Wrong Answers : </td>
            <td><?php echo $wrong; ?></td>
        </tr>
        <tr>
            <td>Total Unattended Questions : </td>
            <td><?php echo $unattended; ?></td>
        </tr>
        <tr>
            <td>Overall Score : </td>
            <td><?php echo $overall;  ?></td>
        </tr>
    </tbody>
  </table>
</div>

</body>
</html>
